function Home() {
  return (
    <>
      <img
        src="https://ewm.swiss/application/files/4715/9362/1165/Car_dealer_web_design_by_EWM_web_design_agency.jpg"
        class="d-block w-100 imgc"
        alt="..."
      />
    </>
  );
}

export default Home;
